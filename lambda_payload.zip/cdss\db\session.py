"""
CDSS data layer – session factory and RDS/Secrets Manager integration.
Use get_session() for all handler DB access; supports DATABASE_URL or RDS_CONFIG_SECRET_NAME (IAM auth).
"""

from __future__ import annotations

import json
import logging
import os
from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

logger = logging.getLogger(__name__)

DATABASE_URL_ENV = "DATABASE_URL"
RDS_CONFIG_SECRET_NAME_ENV = "RDS_CONFIG_SECRET_NAME"
AWS_REGION_ENV = "AWS_REGION"

_engine = None
_SessionLocal: sessionmaker | None = None


def _get_rds_url() -> str | None:
    """Build PostgreSQL URL from Secrets Manager (IAM auth). Returns None if secret or env not set."""
    secret_name = os.environ.get(RDS_CONFIG_SECRET_NAME_ENV)
    if not secret_name or not secret_name.strip():
        return None
    try:
        import boto3
        from botocore.exceptions import ClientError
        from urllib.parse import quote_plus

        client = boto3.client("secretsmanager", region_name=os.environ.get(AWS_REGION_ENV) or "ap-south-1")
        resp = client.get_secret_value(SecretId=secret_name)
        raw = resp.get("SecretString")
        if not raw:
            return None
        config = json.loads(raw)
        host = config.get("host")
        port = config.get("port", 5432)
        database = config.get("database", "cdssdb")
        username = config.get("username")
        region = config.get("region") or os.environ.get(AWS_REGION_ENV) or "ap-south-1"
        if not host or not username:
            logger.warning("RDS secret missing host or username")
            return None
        rds_client = boto3.client("rds", region_name=region)
        password = rds_client.generate_db_auth_token(
            DBHostname=host,
            Port=port,
            DBUsername=username,
            Region=region,
        )
        password_escaped = quote_plus(password)
        return f"postgresql+psycopg2://{username}:{password_escaped}@{host}:{port}/{database}"
    except ClientError as e:
        logger.warning("Secrets Manager get_secret_value failed: %s", e.response.get("Error", {}).get("Code"))
        return None
    except Exception as e:
        logger.warning("RDS URL from secret failed: %s", e)
        return None


def get_engine():
    """Create or return cached SQLAlchemy engine. Uses DATABASE_URL or RDS secret."""
    global _engine
    if _engine is not None:
        return _engine
    url = os.environ.get(DATABASE_URL_ENV)
    if not url or not url.strip():
        url = _get_rds_url()
    if not url:
        raise RuntimeError(
            "Database not configured. Set DATABASE_URL for local Postgres or "
            "RDS_CONFIG_SECRET_NAME and AWS_REGION for Aurora IAM auth."
        )
    if "postgresql://" in url and "postgresql+psycopg2" not in url:
        url = url.replace("postgresql://", "postgresql+psycopg2://", 1)
    _engine = create_engine(url, pool_pre_ping=True, echo=bool(os.environ.get("SQL_ECHO")))
    return _engine


@contextmanager
def get_session(secret_name: str | None = None) -> Generator[Session, None, None]:
    """
    Context manager yielding a SQLAlchemy Session. Commit on exit; rollback on exception.
    secret_name is ignored (kept for API compatibility with code that passes it).
    """
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=get_engine(), autocommit=False, autoflush=False, expire_on_commit=False)
    session = _SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
