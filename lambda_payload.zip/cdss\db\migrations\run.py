"""
Run CDSS DB migrations: create tables from SQLAlchemy models.
Usage: python -m cdss.db.migrations.run [--dry-run]
With --dry-run: print what would be created without connecting to DB.
Without: create all tables (audit_log, patients, visits, surgeries, resources, schedule_slots, medications, reminders).
"""

from __future__ import annotations

import argparse
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="CDSS DB migrations")
    parser.add_argument("--dry-run", action="store_true", help="Print what would run without connecting")
    args = parser.parse_args()

    if args.dry_run:
        from cdss.db.models import Base
        tables = list(Base.metadata.tables.keys())
        print("Dry-run: would create tables:", ", ".join(sorted(tables)))
        return 0

    try:
        from cdss.db.session import get_engine
        from cdss.db.models import Base
        engine = get_engine()
        Base.metadata.create_all(engine)
        from cdss.db.migrations import add_missing_columns
        add_missing_columns.run(engine)
        from cdss.db.migrations import ensure_serial_defaults
        ensure_serial_defaults.run(engine)
        print("Migrations complete. Tables:", ", ".join(sorted(Base.metadata.tables.keys())))
        return 0
    except RuntimeError as e:
        print("Error:", e, file=sys.stderr)
        return 1
    except Exception as e:
        print("Migration failed:", e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
