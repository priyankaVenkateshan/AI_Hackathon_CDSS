"""
POST /agent – chat-style response via Bedrock Converse.
Returns a result object with message, reply, safety_disclaimer.
Safe fallback when Bedrock is not configured.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ChatResult:
    message: str | None
    reply: str
    safety_disclaimer: str


def invoke_chat(user_message: str) -> ChatResult:
    """
    Invoke Bedrock Converse (or equivalent) for chat. Returns validated result.
    When Bedrock is unavailable, returns a safe fallback reply and disclaimer.
    """
    if not (user_message or "").strip():
        return ChatResult(
            message="No message",
            reply="Please provide a message to get a response.",
            safety_disclaimer="AI is for support only. Always follow clinical guidelines and doctor judgment.",
        )
    try:
        import os
        import boto3
        from botocore.exceptions import ClientError

        secret_name = os.environ.get("BEDROCK_CONFIG_SECRET_NAME")
        region = os.environ.get("AWS_REGION", "ap-south-1")
        if not secret_name:
            logger.debug("BEDROCK_CONFIG_SECRET_NAME not set; using fallback")
            return _fallback_reply(user_message)

        client = boto3.client("secretsmanager", region_name=region)
        resp = client.get_secret_value(SecretId=secret_name)
        config = __import__("json").loads(resp.get("SecretString", "{}"))
        model_id = config.get("model_id") or "anthropic.claude-3-haiku-20240307-v1:0"
        bedrock_region = config.get("region") or region

        bedrock = boto3.client("bedrock-runtime", region_name=bedrock_region)
        response = bedrock.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": user_message}]}],
            inferenceConfig={"maxTokens": 1024, "temperature": 0.2},
        )
        output = response.get("output", {})
        if not output or output.get("message", {}).get("role") != "assistant":
            return _fallback_reply(user_message)
        content = output.get("message", {}).get("content", [])
        text = next((c.get("text", "") for c in content if c.get("text")), "")
        return ChatResult(
            message=user_message,
            reply=text.strip() or "I couldn't generate a response. Please try again.",
            safety_disclaimer="AI is for support only. Always follow clinical guidelines and doctor judgment.",
        )
    except ClientError as e:
        logger.warning("Bedrock invoke failed: %s", e.response.get("Error", {}).get("Code"))
        return _fallback_reply(user_message)
    except Exception as e:
        logger.warning("Bedrock chat error: %s", e)
        return _fallback_reply(user_message)


def _fallback_reply(user_message: str) -> ChatResult:
    return ChatResult(
        message=user_message,
        reply="Agent endpoint is ready. Connect Bedrock (set BEDROCK_CONFIG_SECRET_NAME) for live responses.",
        safety_disclaimer="AI is not configured or unavailable. All decisions require qualified clinical judgment.",
    )
