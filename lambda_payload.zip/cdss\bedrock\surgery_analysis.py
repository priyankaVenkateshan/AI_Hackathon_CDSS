"""
Surgery checklist and readiness analysis via Bedrock – CDSS-aligned schemas.

Returns pre_op_status, checklist_flags, risk_factors, requires_senior_review per .cursor/rules/CDSS.mdc.
Safe fallback when Bedrock is not configured.
"""

from __future__ import annotations

import logging
import json
from typing import Any

logger = logging.getLogger(__name__)

# CDSS.mdc: pre_op_status literal
PRE_OP_PENDING = "pending"
PRE_OP_IN_PROGRESS = "in_progress"
PRE_OP_CLEARED = "cleared"
PRE_OP_ON_HOLD = "on_hold"


def get_surgery_checklist_analysis(
    surgery_type: str,
    patient_conditions: str,
    existing_checklist: list[str] | None = None,
) -> dict[str, Any] | None:
    """
    Call Bedrock to generate/refine pre-op checklist and CDSS-aligned readiness.

    Returns dict with: checklist_items (list[str]), pre_op_status, risk_factors,
    requires_senior_review. Returns None when Bedrock unavailable.
    """
    try:
        import os
        import boto3
        from botocore.exceptions import ClientError

        secret_name = os.environ.get("BEDROCK_CONFIG_SECRET_NAME")
        region = os.environ.get("AWS_REGION", "ap-south-1")
        if not secret_name:
            logger.debug("BEDROCK_CONFIG_SECRET_NAME not set; skipping surgery analysis")
            return None

        client = boto3.client("secretsmanager", region_name=region)
        resp = client.get_secret_value(SecretId=secret_name)
        config = json.loads(resp.get("SecretString", "{}"))
        model_id = config.get("model_id") or "anthropic.claude-3-haiku-20240307-v1:0"
        bedrock_region = config.get("region") or region

        prompt = (
            "You are a clinical decision support assistant for surgery planning in an Indian hospital. "
            "Respond with a JSON object only, no markdown.\n"
            "Keys required: checklist_items (array of strings, 6–10 pre-op checklist steps), "
            "pre_op_status (one of: pending, in_progress, cleared, on_hold), "
            "risk_factors (array of strings from patient context), "
            "requires_senior_review (boolean; true if confidence would be low or multiple risk factors).\n"
            f"Surgery type: {surgery_type}. Patient conditions/summary: {patient_conditions or 'none'}.\n"
        )
        if existing_checklist:
            prompt += f"Optionally refine or extend this existing checklist: {existing_checklist}\n"
        prompt += "Output only valid JSON."

        bedrock = boto3.client("bedrock-runtime", region_name=bedrock_region)
        response = bedrock.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={"maxTokens": 512, "temperature": 0.1},
        )
        output = response.get("output", [])
        if not output:
            return None
        content = output[0].get("message", {}).get("content", [])
        text = next((c.get("text", "") for c in content if c.get("text")), "").strip()
        if not text:
            return None

        # Parse JSON from response (allow wrapped in markdown)
        if text.startswith("```"):
            lines = text.split("\n")
            text = "\n".join(
                line for line in lines
                if not line.strip().startswith("```")
            )
        data = json.loads(text)
        checklist_items = data.get("checklist_items")
        if not isinstance(checklist_items, list):
            checklist_items = []
        return {
            "checklist_items": [str(x) for x in checklist_items],
            "pre_op_status": data.get("pre_op_status") or PRE_OP_PENDING,
            "risk_factors": data.get("risk_factors") if isinstance(data.get("risk_factors"), list) else [],
            "requires_senior_review": bool(data.get("requires_senior_review", False)),
        }
    except ClientError as e:
        logger.debug("Bedrock surgery analysis failed: %s", e.response.get("Error", {}).get("Code"))
        return None
    except (json.JSONDecodeError, Exception) as e:
        logger.debug("Surgery analysis parse error: %s", e)
        return None
