"""
Seed CDSS RDS with sample data for development and testing.
Usage: python -m cdss.db.seed [--force]
Uses DATABASE_URL or RDS_CONFIG_SECRET_NAME + AWS_REGION. With --force, clears existing seed data and re-inserts.
"""

from __future__ import annotations

import argparse
import sys
from datetime import date, datetime, timezone


def _now() -> datetime:
    return datetime.now(timezone.utc)


def run_seed(force: bool = False) -> int:
    from cdss.db.session import get_session
    from cdss.db.models import (
        AuditLog,
        Medication,
        Patient,
        Reminder,
        Resource,
        ScheduleSlot,
        Surgery,
        Visit,
    )

    with get_session() as session:
        from sqlalchemy import func, select

        existing = session.scalar(select(func.count(Patient.id)))
        if existing and existing > 0 and not force:
            print("Seed data already present (patients exist). Use --force to replace.")
            return 0

        if force and existing and existing > 0:
            from sqlalchemy import delete
            for model in [Reminder, Medication, ScheduleSlot, Visit, Surgery, Resource, Patient, AuditLog]:
                session.execute(delete(model))
            session.flush()
            print("Cleared existing seed data.")

        # Patients
        patients_data = [
            {
                "id": "PT-1001",
                "name": "Rajesh Kumar",
                "date_of_birth": date(1985, 3, 15),
                "gender": "M",
                "language": "hi",
                "abha_id": None,
                "conditions": ["Hypertension", "Type 2 Diabetes"],
                "allergies": ["Penicillin"],
                "blood_group": "B+",
                "ward": "Ward A",
                "severity": "moderate",
                "status": "active",
                "vitals": {"bp": "130/82", "hr": 78, "temp": 98.4},
                "surgery_readiness": {"cleared": True, "notes": "Pre-op labs pending"},
                "last_visit": date(2025, 2, 20),
                "created_at": _now(),
                "updated_at": _now(),
            },
            {
                "id": "PT-1002",
                "name": "Priya Sharma",
                "date_of_birth": date(1992, 7, 8),
                "gender": "F",
                "language": "en",
                "abha_id": None,
                "conditions": ["Asthma"],
                "allergies": [],
                "blood_group": "O+",
                "ward": None,
                "severity": "low",
                "status": "active",
                "vitals": {"bp": "118/76", "hr": 72, "spo2": 98},
                "surgery_readiness": {},
                "last_visit": date(2025, 3, 1),
                "created_at": _now(),
                "updated_at": _now(),
            },
            {
                "id": "PT-1003",
                "name": "Amit Patel",
                "date_of_birth": date(1978, 11, 22),
                "gender": "M",
                "language": "gu",
                "abha_id": None,
                "conditions": ["COPD", "Hypertension"],
                "allergies": ["Sulfa"],
                "blood_group": "A+",
                "ward": "Ward B",
                "severity": "high",
                "status": "active",
                "vitals": {"bp": "142/88", "hr": 85, "spo2": 94},
                "surgery_readiness": {"cleared": False, "notes": "Cardiology clearance required"},
                "last_visit": date(2025, 2, 28),
                "created_at": _now(),
                "updated_at": _now(),
            },
        ]
        for p in patients_data:
            session.add(Patient(**p))
        session.flush()

        # Visits
        visits_data = [
            {"patient_id": "PT-1001", "doctor_id": "DOC-001", "visit_date": date(2025, 2, 20), "notes": "Routine follow-up. BP controlled.", "summary": "Hypertension stable on current medication.", "created_at": _now()},
            {"patient_id": "PT-1001", "doctor_id": "DOC-001", "visit_date": date(2025, 1, 15), "notes": "Diabetes review.", "summary": "HbA1c 7.2. Continue metformin.", "created_at": _now()},
            {"patient_id": "PT-1002", "doctor_id": "DOC-002", "visit_date": date(2025, 3, 1), "notes": "Asthma check. Inhaler technique reviewed.", "summary": "Asthma well controlled.", "created_at": _now()},
            {"patient_id": "PT-1003", "doctor_id": "DOC-001", "visit_date": date(2025, 2, 28), "notes": "COPD exacerbation follow-up.", "summary": "Improved on steroids. Continue inhalers.", "created_at": _now()},
        ]
        for v in visits_data:
            session.add(Visit(**v))
        session.flush()

        # Surgeries
        surgeries_data = [
            {
                "id": "SRG-001",
                "patient_id": "PT-1001",
                "surgeon_id": "DOC-003",
                "type": "Laparoscopic Cholecystectomy",
                "ot_id": "OT-1",
                "scheduled_date": date(2025, 3, 15),
                "scheduled_time": "09:00",
                "duration_minutes": 90,
                "status": "scheduled",
                "checklist": [
                    {"id": 1, "text": "Confirm patient identity and consent", "completed": True},
                    {"id": 2, "text": "Marking of surgical site", "completed": False},
                    {"id": 3, "text": "Anesthesia safety check", "completed": False},
                ],
                "requirements": {"instruments": ["Laparoscope", "Graspers", "Clip applier"], "complexity": "Moderate"},
                "created_at": _now(),
                "updated_at": _now(),
            },
            {
                "id": "SRG-002",
                "patient_id": "PT-1003",
                "surgeon_id": "DOC-003",
                "type": "Cataract Surgery",
                "ot_id": "OT-2",
                "scheduled_date": date(2025, 3, 18),
                "scheduled_time": "11:00",
                "duration_minutes": 45,
                "status": "scheduled",
                "checklist": [],
                "requirements": {"instruments": ["Phaco machine", "IOL"], "complexity": "Low"},
                "created_at": _now(),
                "updated_at": _now(),
            },
        ]
        for s in surgeries_data:
            session.add(Surgery(**s))
        session.flush()

        # Resources (OTs, equipment, staff)
        resources_data = [
            {"id": "OT-1", "type": "ot", "name": "Operation Theater 1", "status": "available", "availability": {"nextFree": None, "area": "Block A"}, "last_updated": _now()},
            {"id": "OT-2", "type": "ot", "name": "Operation Theater 2", "status": "available", "availability": {"nextFree": None, "area": "Block A"}, "last_updated": _now()},
            {"id": "OT-3", "type": "ot", "name": "Operation Theater 3", "status": "busy", "availability": {"nextFree": "14:00", "area": "Block B"}, "last_updated": _now()},
            {"id": "EQ-1", "type": "equipment", "name": "Ventilator V1", "status": "available", "availability": {"location": "ICU", "assignedTo": None}, "last_updated": _now()},
            {"id": "EQ-2", "type": "equipment", "name": "ECG Machine", "status": "available", "availability": {"location": "Ward A", "assignedTo": None}, "last_updated": _now()},
            {"id": "ST-1", "type": "staff", "name": "Dr. Meera Singh", "status": "available", "availability": {"specialty": "Cardiology", "assignedTo": None}, "last_updated": _now()},
            {"id": "ST-2", "type": "staff", "name": "Dr. Arjun Nair", "status": "busy", "availability": {"specialty": "General Surgery", "assignedTo": "OT-1"}, "last_updated": _now()},
        ]
        for r in resources_data:
            session.add(Resource(**r))
        session.flush()

        # Schedule slots (linked to surgeries)
        slots_data = [
            {"ot_id": "OT-1", "slot_date": date(2025, 3, 15), "slot_time": "09:00", "surgery_id": "SRG-001", "status": "booked", "created_at": _now()},
            {"ot_id": "OT-2", "slot_date": date(2025, 3, 18), "slot_time": "11:00", "surgery_id": "SRG-002", "status": "booked", "created_at": _now()},
            {"ot_id": "OT-1", "slot_date": date(2025, 3, 16), "slot_time": "14:00", "surgery_id": None, "status": "available", "created_at": _now()},
        ]
        for s in slots_data:
            session.add(ScheduleSlot(**s))
        session.flush()

        # Medications
        meds_data = [
            {"patient_id": "PT-1001", "medication_name": "Amlodipine 5mg", "frequency": "Once daily", "next_dose_at": _now(), "status": "active", "created_at": _now()},
            {"patient_id": "PT-1001", "medication_name": "Metformin 500mg", "frequency": "Twice daily", "next_dose_at": _now(), "status": "active", "created_at": _now()},
            {"patient_id": "PT-1002", "medication_name": "Salbutamol Inhaler", "frequency": "As needed", "next_dose_at": None, "status": "active", "created_at": _now()},
            {"patient_id": "PT-1003", "medication_name": "Tiotropium Inhaler", "frequency": "Once daily", "next_dose_at": _now(), "status": "active", "created_at": _now()},
        ]
        for m in meds_data:
            session.add(Medication(**m))
        session.flush()

        # Reminders (link to medication by patient + name for stable ids)
        med_rows = session.execute(select(Medication.id, Medication.patient_id, Medication.medication_name)).all()
        med_map = {(p, n): i for i, p, n in med_rows}
        reminders_data = [
            {"patient_id": "PT-1001", "medication_id": med_map.get(("PT-1001", "Amlodipine 5mg")), "reminder_at": _now(), "sent_at": _now(), "created_at": _now()},
            {"patient_id": "PT-1001", "medication_id": med_map.get(("PT-1001", "Metformin 500mg")), "reminder_at": _now(), "sent_at": None, "created_at": _now()},
            {"patient_id": "PT-1003", "medication_id": med_map.get(("PT-1003", "Tiotropium Inhaler")), "reminder_at": _now(), "sent_at": _now(), "created_at": _now()},
        ]
        for r in reminders_data:
            session.add(Reminder(**r))
        session.flush()

        # Audit log
        audit_data = [
            {"user_id": "DOC-001", "user_email": "doctor@cdss.ai", "action": "GET /api/v1/patients", "resource": "/api/v1/patients", "timestamp": _now()},
            {"user_id": "DOC-001", "user_email": "doctor@cdss.ai", "action": "GET /api/v1/patients/PT-1001", "resource": "/api/v1/patients/PT-1001", "timestamp": _now()},
            {"user_id": "admin-1", "user_email": "admin@cdss.ai", "action": "GET /api/v1/admin/audit", "resource": "/api/v1/admin/audit", "timestamp": _now()},
        ]
        for a in audit_data:
            session.add(AuditLog(**a))

    print("Seed complete: 3 patients, 4 visits, 2 surgeries, 7 resources, 3 schedule slots, 4 medications, 3 reminders, 3 audit entries.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Seed CDSS RDS with sample data")
    parser.add_argument("--force", action="store_true", help="Clear existing seed data and re-insert")
    args = parser.parse_args()
    try:
        return run_seed(force=args.force)
    except RuntimeError as e:
        print("Error:", e, file=sys.stderr)
        return 1
    except Exception as e:
        print("Seed failed:", e, file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
