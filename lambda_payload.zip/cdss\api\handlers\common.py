"""
Shared helpers for CDSS API handlers.
Per project-conventions: no PHI in logs; use for consistent JSON responses and body/query parsing.
"""

from __future__ import annotations

import json


def json_response(status_code: int, body: dict) -> dict:
    """
    Return a Lambda proxy response dict with JSON body.
    Use this for all handler returns so API Gateway gets statusCode, headers, body.
    """
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body) if not isinstance(body, str) else body,
    }


def parse_body_json(event: dict) -> dict:
    """
    Parse request body from API Gateway event as JSON.
    Returns {} if body is missing or invalid.
    """
    raw = event.get("body")
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return raw
    try:
        return json.loads(raw) if isinstance(raw, str) and raw.strip() else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def query_int(event: dict, name: str, default: int) -> int:
    """
    Read an integer query parameter from the event.
    event["queryStringParameters"][name] is parsed as int; invalid/missing returns default.
    """
    params = event.get("queryStringParameters") or event.get("queryParameters") or {}
    value = params.get(name)
    if value is None:
        return default
    try:
        return int(value)
    except (ValueError, TypeError):
        return default
