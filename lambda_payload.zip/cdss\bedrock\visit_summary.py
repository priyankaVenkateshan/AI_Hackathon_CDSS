"""
Visit/consultation summary and medical entity extraction via Bedrock (Phase 7).
Used by Engagement API for conversation intelligence: generate summary and extract entities from transcript.
Returns None when Bedrock is unavailable.
"""

from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger(__name__)


def _get_bedrock_client():
    """Return Bedrock runtime client and model id from Secrets Manager, or (None, None)."""
    try:
        import os
        import boto3
        from botocore.exceptions import ClientError

        secret_name = os.environ.get("BEDROCK_CONFIG_SECRET_NAME")
        region = os.environ.get("AWS_REGION", "ap-south-1")
        if not secret_name:
            return None, None
        sm = boto3.client("secretsmanager", region_name=region)
        resp = sm.get_secret_value(SecretId=secret_name)
        config = json.loads(resp.get("SecretString", "{}"))
        model_id = config.get("model_id") or "anthropic.claude-3-haiku-20240307-v1:0"
        bedrock_region = config.get("region") or region
        client = boto3.client("bedrock-runtime", region_name=bedrock_region)
        return client, model_id
    except (ClientError, Exception) as e:
        logger.debug("Bedrock config error: %s", e)
        return None, None


def generate_visit_summary(transcript_text: str, patient_context: str = "") -> str | None:
    """
    Generate a short patient-facing consultation summary from transcript using Bedrock.
    Returns None when Bedrock is not configured or on failure.
    """
    if not (transcript_text or "").strip():
        return None
    client, model_id = _get_bedrock_client()
    if not client or not model_id:
        return None
    try:
        prompt_parts = [
            "You are a clinical decision support assistant for an Indian hospital.",
            "Generate a brief, patient-friendly summary (2–4 sentences) of this consultation transcript.",
            "Use simple language. Include: main complaints, findings or advice, and any follow-up.",
        ]
        if patient_context:
            prompt_parts.append(f"Patient context (for reference only): {patient_context[:500]}")
        prompt_parts.append("Do not include identifying details. End with a disclaimer that this is AI-generated support only.")
        prompt_parts.append("\n--- Transcript ---\n" + (transcript_text[:8000] if len(transcript_text) > 8000 else transcript_text))

        prompt = "\n\n".join(prompt_parts)
        response = client.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={"maxTokens": 512, "temperature": 0.2},
        )
        output = response.get("output", {})
        if not output:
            return None
        content = output.get("message", {}).get("content", [])
        text = next((c.get("text", "") for c in content if c.get("text")), "")
        return text.strip() or None
    except Exception as e:
        logger.debug("generate_visit_summary error: %s", e)
        return None


def extract_medical_entities(transcript_text: str) -> dict[str, Any] | None:
    """
    Extract medical entities (symptoms, diagnoses, medications, key findings) from transcript using Bedrock.
    Returns a structured dict e.g. { "symptoms": [], "diagnoses": [], "medications": [], "key_findings": [] } or None.
    """
    if not (transcript_text or "").strip():
        return None
    client, model_id = _get_bedrock_client()
    if not client or not model_id:
        return None
    try:
        prompt = """You are a clinical extraction assistant. From the following consultation transcript, extract medical entities in JSON format only.
Output a single JSON object with these keys (arrays of strings): "symptoms", "diagnoses", "medications", "key_findings".
Use empty arrays [] for missing categories. No other text.

--- Transcript ---
""" + (transcript_text[:6000] if len(transcript_text) > 6000 else transcript_text)

        response = client.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={"maxTokens": 1024, "temperature": 0.0},
        )
        output = response.get("output", {})
        if not output:
            return None
        content = output.get("message", {}).get("content", [])
        text = next((c.get("text", "") for c in content if c.get("text")), "").strip()
        if not text:
            return None
        # Strip markdown code block if present
        if text.startswith("```"):
            lines = text.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            text = "\n".join(lines)
        data = json.loads(text)
        if isinstance(data, dict):
            return {
                "symptoms": data.get("symptoms") if isinstance(data.get("symptoms"), list) else [],
                "diagnoses": data.get("diagnoses") if isinstance(data.get("diagnoses"), list) else [],
                "medications": data.get("medications") if isinstance(data.get("medications"), list) else [],
                "key_findings": data.get("key_findings") if isinstance(data.get("key_findings"), list) else [],
            }
        return None
    except json.JSONDecodeError as e:
        logger.debug("extract_medical_entities JSON error: %s", e)
        return None
    except Exception as e:
        logger.debug("extract_medical_entities error: %s", e)
        return None
