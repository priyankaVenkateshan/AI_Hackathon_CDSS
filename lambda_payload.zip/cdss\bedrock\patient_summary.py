"""
Patient summary via Bedrock – structured summary for clinical decision support.
Returns None when Bedrock is unavailable; handlers treat None as no AI summary.
"""

from __future__ import annotations

import logging
from typing import Any, Iterable

logger = logging.getLogger(__name__)


def _build_history_context(patient: Any, visits: Iterable[Any] | None) -> str:
    """
    Build a textual patient history context from visits/consultations.
    Uses only non-identifying clinical content (dates, notes, summaries).
    """
    if not visits:
        return ""

    lines: list[str] = []
    for v in visits:
        visit_date = getattr(v, "visit_date", None)
        notes = getattr(v, "notes", "") or ""
        summary = getattr(v, "summary", "") or ""
        date_str = visit_date.isoformat() if hasattr(visit_date, "isoformat") else ""
        fragment_parts: list[str] = []
        if date_str:
            fragment_parts.append(f"Date: {date_str}")
        if notes:
            fragment_parts.append(f"Notes: {notes}")
        if summary:
            fragment_parts.append(f"AI summary: {summary}")
        if fragment_parts:
            lines.append(" | ".join(fragment_parts))

    history = "\n".join(lines)
    # Guardrail: avoid excessively long prompts; keep recent history in context.
    max_len = 5000
    if len(history) > max_len:
        history = history[-max_len:]
    return history


def get_patient_summary(patient: Any, visits: Iterable[Any] | None = None) -> str | None:
    """
    Generate a short clinical summary for the patient using Bedrock with RAG-style context.

    - Uses structured data from the patient record (conditions, status).
    - Optionally includes recent visit history text built from consultations.
    - Returns None when Bedrock is not configured or on failure.
    """
    try:
        import os
        import boto3
        from botocore.exceptions import ClientError

        secret_name = os.environ.get("BEDROCK_CONFIG_SECRET_NAME")
        region = os.environ.get("AWS_REGION", "ap-south-1")
        if not secret_name:
            logger.debug("BEDROCK_CONFIG_SECRET_NAME not set; skipping patient summary")
            return None

        client = boto3.client("secretsmanager", region_name=region)
        resp = client.get_secret_value(SecretId=secret_name)
        config = __import__("json").loads(resp.get("SecretString", "{}"))
        model_id = config.get("model_id") or "anthropic.claude-3-haiku-20240307-v1:0"
        bedrock_region = config.get("region") or region

        conditions = getattr(patient, "conditions", None) or []
        conditions_str = ", ".join(conditions) if isinstance(conditions, list) else str(conditions)
        status = getattr(patient, "status", None) or ""
        severity = getattr(patient, "severity", None) or ""

        history_context = _build_history_context(patient, visits)

        prompt_parts = [
            "You are a clinical decision support assistant for doctors in an Indian hospital.",
            "Summarize this patient's current situation in 2–3 sentences for a doctor.",
            f"Known conditions: {conditions_str or 'none recorded'}.",
        ]
        if severity or status:
            prompt_parts.append(f"Recorded severity/status: {severity or status}.")
        if history_context:
            prompt_parts.append(
                "Use the following recent consultation history as clinical context:\n"
                f"{history_context}"
            )
        prompt_parts.append(
            "Focus on what matters for near-term clinical decisions and surgery readiness."
        )
        prompt_parts.append(
            "Do not include any patient-identifying information. "
            "End with a brief safety reminder that AI is support-only."
        )

        prompt = "\n\n".join(prompt_parts)

        bedrock = boto3.client("bedrock-runtime", region_name=bedrock_region)
        response = bedrock.converse(
            modelId=model_id,
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={"maxTokens": 256, "temperature": 0.1},
        )
        output = response.get("output", [])
        if not output:
            return None
        content = output[0].get("message", {}).get("content", [])
        text = next((c.get("text", "") for c in content if c.get("text")), "")
        cleaned = text.strip()
        if not cleaned:
            return None
        return cleaned
    except ClientError as e:
        logger.debug("Bedrock patient summary failed: %s", e.response.get("Error", {}).get("Code"))
        return None
    except Exception as e:
        logger.debug("Patient summary error: %s", e)
        return None
