"""CDSS S3 helpers for documents and transcripts."""
