"""
CDSS Bedrock integration – chat and patient summary.
Safe fallbacks when Bedrock is not configured or unavailable.
"""
